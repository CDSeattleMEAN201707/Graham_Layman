import { Component } from '@angular/core';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent {
  title = 'app';
  selectedTimeZone = "PST";
  hide = true;
  time = new Date();
  
  setTimeZone(timezone){
    this.hide = false;
    this.time = new Date();
    let offset:number = 0;
    if(timezone === "MST"){
      offset += 1;
    }else if(timezone === "CST"){
      offset += 2;
    }else if(timezone === "EST"){
      offset += 3;
    }else if(timezone === 'null'){
      this.hide = true;
    }
    this.selectedTimeZone = timezone;
    this.time.setHours(this.time.getHours()+offset);
    this.hideStatus();
  }
  hideStatus(){
    console.log(this.hide);
    let el = document.getElementById("timeDisplay");
    if(this.hide){
      el.style.visibility = 'hidden';
    }
    else{
      el.style.visibility = 'visible';
    }
  }
}
